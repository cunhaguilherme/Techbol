package com.br.util;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.icu.text.MessagePattern;
import android.os.CountDownTimer;
import android.util.Log;
import android.widget.TextView;

import com.br.activity.NavegacaoActivity;
import com.br.activity.PartidaActivity;
import com.br.bean.Partida;

import java.util.Calendar;

/**
 * Created by Guilherme on 20/09/2016.
 */
public class Cronometro extends CountDownTimer{

    private Context context;
    private TextView txt;
    private long timeInFuture;
    private AlertDialog alerta;

    public Cronometro(Context context, TextView txt, long timeInFuture, long interval) {
        super(timeInFuture, interval);
        this.context = context;
        this.txt = txt;
    }

    @Override
    public void onTick(long l) {
        Log.i("FALTA: ","Timer: " + l);
        timeInFuture = l;
        txt.setText(corrigirTempo(true, l) + ":" + corrigirTempo(false, l));
    }

    @Override
    public void onFinish() {
        timeInFuture -= 1000;
        txt.setText(corrigirTempo(true, timeInFuture) + ":" + corrigirTempo(false, timeInFuture));
        alertar();
    }

    private String corrigirTempo(boolean isMinute, long l) {
        String aux;
        int constCalendar = isMinute ? Calendar.MINUTE : Calendar.SECOND;
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(l);

        aux = c.get(constCalendar) < 10 ? "0"+c.get(constCalendar) : ""+c.get(constCalendar);

        return (aux);
    }

    private void alertar(){

        //Cria o gerador do AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        //Define o título
        builder.setTitle("Atenção");
        //Define a mensagem
        builder.setMessage("Fim de jogo! Quem ganhou, ganhou.. Quem não ganhou, não ganha mais!!!");
        //Define um botão positivo
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent nav = new Intent(context, NavegacaoActivity.class);
                context.startActivity(nav);
                alerta.dismiss();
            }
        });

        //Cria o AlertDialog
        alerta = builder.create();
        //Exibe
        alerta.show();

    }
}
