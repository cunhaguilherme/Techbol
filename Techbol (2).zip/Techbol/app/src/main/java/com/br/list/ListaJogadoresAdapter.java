package com.br.list;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.br.activity.R;
import com.br.bean.Jogador;

import java.io.FileInputStream;
import java.util.List;

/**
 * Created by Guilherme on 10/09/2016.
 */
public class ListaJogadoresAdapter extends ArrayAdapter<Jogador> {
    private Context context;
    private List<Jogador> jogadores = null;
    ImageView imageViewJogador;

    public ListaJogadoresAdapter(Context context,  List<Jogador> jogadores) {
        super(context,0, jogadores);
        this.jogadores = jogadores;
        this.context = context;
        Log.i("CONSTRUTOR"," - construindo a lista personalizada");
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        Jogador jogador = jogadores.get(position);

        if(view == null)
            view = LayoutInflater.from(context).inflate(R.layout.item_list_jogadores, null);

        imageViewJogador = (ImageView) view.findViewById(R.id.imgViewJogador);
        carregarFoto(jogador.getFoto());

        TextView textViewNomeJogador = (TextView) view.findViewById(R.id.txtNomeJogador);
        textViewNomeJogador.setText(jogador.getNome());

        TextView textViewVitorias = (TextView)view.findViewById(R.id.txtVitoriasJogador);
        String textoVitorias = String.valueOf(jogador.getVitoria());
        textViewVitorias.setText("Vitórias: " + textoVitorias);

        return view;
    }

    private void carregarFoto(String localFoto) {

        FileInputStream imgFile;
        Bitmap imagemFoto = null;
        try{
            //Pegar o arquivo do armazenamento
            imgFile = new FileInputStream(localFoto);

            //Carregar arquivo de imagem
            imagemFoto = BitmapFactory.decodeStream(imgFile);

            //Fechar o InputStream
            imgFile.close();

        }catch(Exception e){
            e.printStackTrace();
        }

        if(imagemFoto != null){
            imagemFoto = Bitmap.createScaledBitmap(imagemFoto, 120, 120, true);
        }

        //Atualiza a imagem exibida na listagem
        imageViewJogador.setImageBitmap(imagemFoto);

    }
}
