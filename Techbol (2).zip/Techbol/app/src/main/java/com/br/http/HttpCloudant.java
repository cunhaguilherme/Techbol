package com.br.http;

import android.util.Base64;

import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Created by Guilherme on 08/09/2016.
 */
public class HttpCloudant {

    private String json, requestMethod, userName, password, request;

    public HttpURLConnection getClient() throws Exception {
        //URL API Cloudant
        URL url = new URL(getRequest());

        HttpURLConnection client = (HttpURLConnection) url.openConnection();
        client.setRequestProperty("Content-Type", "application/json");
        client.setRequestProperty("charset", "utf-8");
        //Métodos GET POST...
        client.setRequestMethod(getRequestMethod());
        client.setDoOutput(true);
        client.setDoInput(true);
        //Usuário e senha...
        String userName = getUserName();
        String password = getPassword();
        //Selectors e Json para gravação54
        String json = getJson();
        String encodedPassword = userName + password;
        String encoded = Base64.encodeToString(encodedPassword.getBytes(), Base64.DEFAULT);
        //Autorização Basic com usuário e senha
        client.setRequestProperty("Authorization", "Basic" + encoded);

        OutputStreamWriter wr;

        wr = new OutputStreamWriter(client.getOutputStream());
        //Envio Json
        wr.write(json);
        wr.close();

        return client;
    }

    public String getJson() {
        return json;
    }

    public void setJson(String json) {
        this.json = json;
    }

    public String getRequestMethod() {
        return requestMethod;
    }

    public void setRequestMethod(String requestMethod) {
        this.requestMethod = requestMethod;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRequest() {
        return request;
    }

    public void setRequest(String request) {
        this.request = request;
    }

    public HttpCloudant() {

    }
}

