package com.br.bean;

/**
 * Created by Guilherme on 08/09/2016.
 */
public class Usuario {

    private String tipo = "USUARIO";
    private String usuario;
    private String senha;

    public Usuario(){
        super();
    }

    public Usuario(String usuario,String senha){
        this.usuario = usuario;
        this.senha = senha;
    }

    public void setUsuario(String usuario){
        this.usuario = usuario;
    }

    public String getUsuario(){
        return this.usuario;
    }

    public void setSenha(String senha){
        this.senha = senha;
    }

    public String getSenha(){
        return this.senha;
    }

    public String toString(){
        return this.usuario + " - " + this.senha;
    }
}
