package com.br.bean;

/**
 * Created by Guilherme on 17/09/2016.
 */
public class Partida {

    private String _id;
    private String tipo = "PARTIDA";
    private int codigo;
    private String hashtag;
    private String nivel;
    private String campeonato;
    private int tempo;
    private int gol;
    private String jogadorCasa;
    private String jogadorVisitante;
    private String vencedor;

    public Partida() {
        this.gol = 0;
        this.vencedor = "";
    }

    public Partida(int codigo, String nivel, String campeonato, int tempo, String jogadorCasa, String jogadorVisitante) {
        this.codigo = codigo;
        this.nivel = nivel;
        this.campeonato = campeonato;
        this.tempo = tempo;
        this.jogadorCasa = jogadorCasa;
        this.jogadorVisitante = jogadorVisitante;
        this.gol = 0;
    }

    public String get_id(){
        return this._id;
    }

    public void set_id(){
        this._id = this.campeonato + this.codigo;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNivel() {
        return nivel;
    }

    public void setNivel(String nivel) {
        this.nivel = nivel;
    }

    public String getCampeonato() {
        return campeonato;
    }

    public void setCampeonato(String campeonato) {
        this.campeonato = campeonato;
    }

    public int getTempo() {
        return tempo;
    }

    public void setTempo(int tempo) {
        this.tempo = tempo;
    }

    public int getGol() {
        return gol;
    }

    public void setGol(int gol) {
        this.gol = gol;
    }

    public String getJogadorCasa() {
        return jogadorCasa;
    }

    public void setJogadorCasa(String jogadorCasa) {
        this.jogadorCasa = jogadorCasa;
    }

    public String getJogadorVisitante() {
        return jogadorVisitante;
    }

    public void setJogadorVisitante(String jogadorVisitante) {
        this.jogadorVisitante = jogadorVisitante;
    }

    public String getVencedor() {
        return vencedor;
    }

    public void setVencedor(String vencedor) {
        this.vencedor = vencedor;
    }

    public String getHashtag() {
        return hashtag;
    }

    public void setHashtag() {
        this.hashtag = "#" + this.campeonato + this.codigo;
    }

    public String getTipo() {
        return tipo;
    }

    public String toString(){
        return "Partida " + this.getCodigo() + " - " + this.getNivel() + " - Vencedor: " + this.getVencedor();
    }

}
