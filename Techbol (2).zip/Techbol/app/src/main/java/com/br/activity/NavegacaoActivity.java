package com.br.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class NavegacaoActivity extends AppCompatActivity {

    private Button btCadastrar;
    private Button btCampeonato;
    private Button btPartida;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navegacao);

        btCadastrar = (Button) findViewById(R.id.btnCadastrar);
        btCampeonato = (Button) findViewById(R.id.btnCampeonato);
        btPartida = (Button) findViewById(R.id.btnPartida);
    }

    public void cadastrarJogador(View v){
        Intent cadastro = new Intent(this, CadastroActivity.class);
        startActivity(cadastro);
    }

    public void criarCampeonato(View v){
        Intent campeonato = new Intent(this, CampeonatoActivity.class);
        startActivity(campeonato);
    }

    public void iniciarPartida(View v){
        Intent filtro = new Intent(this, FiltroActivity.class);
        startActivity(filtro);
    }
}
