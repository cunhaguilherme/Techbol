package com.br.bean;

/**
 * Created by Guilherme on 10/09/2016.
 */
public class Jogador {
    private String tipo = "JOGADOR";
    private String nome;
    private String twitter;
    private String serie;
    private String foto;
    private int vitoria;
    private int empate;
    private int derrota;
    private int gol;

    public Jogador(){
        super();
    }

    public Jogador(String nome, String twitter, String serie, String foto, int vitoria, int empate, int derrota, int gol){
        this.nome = nome;
        this.twitter = twitter;
        this.serie = serie;
        this.foto = foto;
        this.vitoria = vitoria;
        this.empate = empate;
        this.derrota = derrota;
        this.gol = gol;
    }

    public String getFoto(){
        return this.foto;
    }

    public void setFoto(String foto){
        this.foto = foto;
    }

    public String getSerie() {
        return serie;
    }

    public void setSerie(String serie) {
        this.serie = serie;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTwitter() {
        return twitter;
    }

    public void setTwitter(String twitter) {
        this.twitter = twitter;
    }

    public int getVitoria() {
        return vitoria;
    }

    public void setVitoria(int vitoria) {
        this.vitoria = vitoria;
    }

    public int getEmpate() {
        return empate;
    }

    public void setEmpate(int empate) {
        this.empate = empate;
    }

    public int getDerrota() {
        return derrota;
    }

    public void setDerrota(int derrota) {
        this.derrota = derrota;
    }

    public int getGol() {
        return gol;
    }

    public void setGol(int gol) {
        this.gol = gol;
    }

    public String toString(){
        return this.nome + " - " + this.twitter + " - " + this.serie + " - " + this.foto + " - "  + this.vitoria +
                " - " + this.empate + " - " + this.derrota + " - " + this.gol;
    }


}
