package com.br.bean;

/**
 * Created by Guilherme on 10/09/2016.
 */
public class Campeonato {
    private String _id;
    private String tipo = "CAMPEONATO";
    private String titulo;
    private int qtdJogadores;
    private int tempo;
    private int maximoGols;
    private int qtdPartidas;

    public Campeonato() {
    }

    public Campeonato(String titulo, int qtdJogadores, int tempo, int maximoGols) {
        this.titulo = titulo;
        this.qtdJogadores = qtdJogadores;
        this.tempo = tempo;
        this.maximoGols = maximoGols;
        this.qtdPartidas = qtdJogadores/2;
    }

    public String get_id(){ return this._id; }

    public void set_id(){ this._id = this.titulo; }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getQtdPartidas() {
        return qtdPartidas;
    }

    public void setQtdPartidas() { this.qtdPartidas = this.getQtdJogadores() - 1; }

    public int getMaximoGols() {
        return maximoGols;
    }

    public void setMaximoGols(int maximoGols) {
        this.maximoGols = maximoGols;
    }

    public int getTempo() {
        return tempo;
    }

    public void setTempo(int tempo) {
        this.tempo = tempo;
    }

    public int getQtdJogadores() {
        return qtdJogadores;
    }

    public void setQtdJogadores(int qtdJogadores) {
        this.qtdJogadores = qtdJogadores;
    }

    public String toString(){
        return "Campeonato: " + this.getTitulo();
    }

}
