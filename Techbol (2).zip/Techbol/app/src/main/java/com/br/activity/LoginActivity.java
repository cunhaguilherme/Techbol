package com.br.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.br.bean.Usuario;
import com.br.http.HttpCloudant;
import com.google.gson.Gson;


import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends AppCompatActivity {

    private EditText edUsuario;
    private EditText edSenha;
    private Button btEntrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edUsuario = (EditText) findViewById(R.id.edtUsuario);
        edSenha = (EditText) findViewById(R.id.edtSenha);
        btEntrar = (Button) findViewById(R.id.btnEntrar);
    }

    public void entrar(View v){
        String usuario = edUsuario.getText().toString();
        String senha = edSenha.getText().toString();

        if(usuario.length()>3 && !(usuario.equals("   ") )){
            new LogarTask().execute(usuario,senha);
        }else{
            Toast.makeText(this, "Usuário e/ou senha incompletos!",Toast.LENGTH_SHORT).show();
        }

    }

    private class LogarTask extends AsyncTask<String,Void,String> {

        private ProgressDialog progress;

        @Override
        protected void onPreExecute(){
            progress = ProgressDialog.show
                    (LoginActivity.this, "Aguarde..", "Buscando dados no servidor");
        }

        @Override
        protected String doInBackground(String... params) {
            HttpCloudant http = new HttpCloudant();
            http.setRequest("https://9a90ba7e-9c8d-4150-8e5f-bccd9f2bead7-bluemix.cloudant.com/tec_db/_find");
            http.setRequestMethod("POST");
            http.setJson("{\"selector\": {\"usuario\": \"" + params[0] + "\"}}");
            String log = "Usuário: " + params[0] + " - Senha: " + params[1];
            Log.i("DADOS:", log);
            String retorno ="";

            try {
                HttpURLConnection client = http.getClient();
                int statusCodeHTTP = client.getResponseCode();
                StringBuilder sb = new StringBuilder();

                if (statusCodeHTTP == HttpURLConnection.HTTP_OK) {
                    BufferedReader br = new BufferedReader
                            (new InputStreamReader
                                    (client.getInputStream(), "utf-8"));
                    String line = null;

                    while ((line = br.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                    br.close();

                    JSONParser parser = new JSONParser();
                    Log.i("JSON",sb.toString());
                    JSONObject jsonSaida = (JSONObject) parser.parse(sb.toString());
                    JSONArray jsonArray = (JSONArray) jsonSaida.get("docs");

                    Gson gson = new Gson();

                    List<Usuario> capturas = new ArrayList<>();

                    for (Object object : jsonArray) {
                        JSONObject jsonObj = (JSONObject) object;
                        capturas.add(gson.fromJson(jsonObj.toString(), Usuario.class));
                        //retorno += jsonObj;
                    }


                    if(capturas.get(0).getUsuario().equals(params[0])  && capturas.get(0).getSenha().equals(params[1])){
                        retorno = "Bem-vindo!";
                    }


                } else {
                    //Toast.makeText(this,"Erro na requisição: " + statusCodeHTTP, Toast.LENGTH_SHORT).show();
                    retorno = statusCodeHTTP +"";
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return retorno;
        }

        @Override
        protected void onPostExecute(String s) {
            progress.dismiss();
            if(s.equals("Bem-vindo!")) {
                Toast.makeText(LoginActivity.this, s, Toast.LENGTH_SHORT).show();
                Intent nav = new Intent(LoginActivity.this, NavegacaoActivity.class);
                startActivity(nav);
            }else{
                Toast.makeText(LoginActivity.this, "Dados inválidos " + s , Toast.LENGTH_SHORT).show();
                edUsuario.setText("");
                edSenha.setText("");
            }
        }
    }
}
