package com.br.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.br.bean.Campeonato;
import com.br.bean.Jogador;
import com.br.bean.Partida;
import com.br.http.HttpCloudant;
import com.br.list.ListaJogadoresAdapter;
import com.google.gson.Gson;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class SelecaoActivity extends AppCompatActivity {

    private String tituloCampeonato;
    private int qtdJogadores;
    private int JOGADORES;
    private int TEMPO;
    private TextView txSelecaoJogadores;
    private ListView liJogadores;

    //Lista de selecionados
    private List<Jogador> selecionados = new ArrayList<Jogador>();
    private List<Integer> indices = new ArrayList<Integer>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selecao);

        Intent intent = getIntent();
        tituloCampeonato = intent.getStringExtra("titulo");
        qtdJogadores = intent.getIntExtra("qtdJogadores", 0);
        TEMPO = intent.getIntExtra("tempo",2);
        JOGADORES = qtdJogadores;

        txSelecaoJogadores = (TextView) findViewById(R.id.txtSelecaoJogadores);
        txSelecaoJogadores.setText("Selecione " + qtdJogadores + " jogadores:");

        Log.i("Inicio", "inicio da seleção");
        liJogadores = (ListView) findViewById(R.id.livJogadores);

        new SelecionarTask().execute();

        liJogadores.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                view.setSelected(true);

                //Verificar se a qtd de jogadores selecionados alcançou o número de jogadores estipulados
                //do campeonato
                if(selecionados.size() < JOGADORES){
                    if(indices.contains(i)){
                        int posicaoJogador = selecionados.indexOf(adapterView.getItemAtPosition(i));
                        int posicao = indices.indexOf(i);
                        selecionados.remove(posicaoJogador);
                        indices.remove(posicao);
                        qtdJogadores += 1;
                        txSelecaoJogadores.setText("Selecione " + qtdJogadores + " jogadores:");
                    }else{
                        indices.add(i);
                        Log.i("SELECIONADO: ", adapterView.getItemAtPosition(i).toString());
                        Jogador jogador = (Jogador) adapterView.getItemAtPosition(i);
                        selecionados.add(jogador);
                        qtdJogadores -= 1;
                        txSelecaoJogadores.setText("Selecione " + qtdJogadores + " jogadores:");
                        Toast.makeText(SelecaoActivity.this, jogador.getNome(), Toast.LENGTH_SHORT).show();

                        //Quando todos estiverem selecionados, formar as chaves das partidas
                        if(qtdJogadores == 0){
                            int qtdPartidas = JOGADORES - 1;
                            Collections.shuffle(selecionados);

                            String codigo = "";
                            String campeonato = "";
                            String tempo = "";
                            String nivel = "";
                            String jogadorCasa = "";
                            String jogadorVisitante = "";

                            switch(qtdPartidas){
                                case 1:
                                    //Rodar uma única vez o código para criar partida
                                    codigo = "1";
                                    campeonato = tituloCampeonato;
                                    nivel = "FINAL";
                                    tempo = String.valueOf(TEMPO);
                                    jogadorCasa = selecionados.get(0).getNome();
                                    jogadorVisitante = selecionados.get(1).getNome();

                                    new criarPartidaTask().execute(codigo, campeonato, nivel, tempo,
                                            jogadorCasa, jogadorVisitante);

                                    break;
                                case 3:
                                    //Rodar duas vezes para as 2 partidas iniciais
                                    for(int x=1; x<5; x+=2){
                                        if(x == 1){
                                            codigo = String.valueOf(x);
                                        }else{
                                            codigo = String.valueOf(x-1);
                                        }

                                        campeonato = tituloCampeonato;
                                        nivel = "SEMI-FINAL";
                                        tempo = String.valueOf(TEMPO);
                                        jogadorCasa = selecionados.get(x-1).getNome();
                                        jogadorVisitante = selecionados.get(x).getNome();

                                        new criarPartidaTask().execute(codigo, campeonato, nivel, tempo,
                                                jogadorCasa, jogadorVisitante);
                                    }

                                    //Rodar última vez para a final com quem ganhar
                                    codigo = "3";
                                    campeonato = tituloCampeonato;
                                    nivel = "FINAL";
                                    tempo = String.valueOf(TEMPO);
                                    jogadorCasa = "";
                                    jogadorVisitante = "";

                                    new criarPartidaTask().execute(codigo, campeonato, nivel, tempo,
                                            jogadorCasa, jogadorVisitante);

                                    break;
                                case 7:
                                    int c = 1;
                                    //Rodar quatro vezes para as 4 partidas iniciais
                                    for(int x=1; x<8; x+=2){

                                        if(x == 1) {
                                            codigo = String.valueOf(x);
                                        }else{
                                            codigo = String.valueOf(x-c);
                                            c++;
                                        }
                                        campeonato = tituloCampeonato;
                                        nivel = "QUARTAS-FINAL";
                                        tempo = String.valueOf(TEMPO);
                                        jogadorCasa = selecionados.get(x-1).getNome();
                                        jogadorVisitante = selecionados.get(x).getNome();

                                        new criarPartidaTask().execute(codigo, campeonato, nivel, tempo,
                                                jogadorCasa, jogadorVisitante);


                                    }

                                    //Rodar duas vezes para as semi-finais
                                    for(int x=5; x<7 ; x++){
                                        codigo = String.valueOf(x);
                                        campeonato = tituloCampeonato;
                                        nivel = "SEMI-FINAL";
                                        tempo = String.valueOf(TEMPO);
                                        jogadorCasa = "";
                                        jogadorVisitante = "";

                                        new criarPartidaTask().execute(codigo, campeonato, nivel, tempo,
                                                jogadorCasa, jogadorVisitante);
                                    }

                                    //Rodar última vez para a final com quem ganhar
                                    codigo = "7";
                                    campeonato = tituloCampeonato;
                                    nivel = "FINAL";
                                    tempo = String.valueOf(TEMPO);
                                    jogadorCasa = "";
                                    jogadorVisitante = "";

                                    new criarPartidaTask().execute(codigo, campeonato, nivel, tempo,
                                            jogadorCasa, jogadorVisitante);

                                    break;
                                default:
                                    break;
                            }

                            Intent navegacao = new Intent(SelecaoActivity.this, NavegacaoActivity.class);
                            startActivity(navegacao);
                        }
                    }

                }


            }
        });
    }

    private class SelecionarTask extends AsyncTask<String,Void,String>{

        private ProgressDialog progress;

        @Override
        protected void onPreExecute(){
            progress = ProgressDialog.show
                    (SelecaoActivity.this, "Aguarde..", "Buscando dados no servidor");
        }

        @Override
        protected void onPostExecute(String s){
            progress.dismiss();
            if(s != null){
                JSONParser parser = new JSONParser();
                Log.i("JSON", s);
                JSONObject jsonSaida = null;
                try {
                    jsonSaida = (JSONObject) parser.parse(s);
                    JSONArray jsonArray = (JSONArray) jsonSaida.get("docs");

                    Gson gson = new Gson();

                    List<Jogador> capturas = new ArrayList<>();

                    for (Object object : jsonArray) {
                        JSONObject jsonObj = (JSONObject) object;
                        Log.i("JSONObject:", jsonObj.toString());
                        capturas.add(gson.fromJson(jsonObj.toString(), Jogador.class));
                        //retorno += jsonObj;
                    }

                    //Tipo de LIST CONVENCIONAL
                    //ArrayAdapter<Jogador> jogadoresAdapter = new ArrayAdapter<Jogador>
                            //(SelecaoActivity.this, android.R.layout.simple_list_item_1, capturas);

                    //Tipo de LIST PERSONALIZADO
                    final ListaJogadoresAdapter jogadoresAdapter =
                            new ListaJogadoresAdapter
                                    (SelecaoActivity.this, capturas);
                    liJogadores.setAdapter(jogadoresAdapter);

                } catch (ParseException e) {
                    e.printStackTrace();
                }

            }
        }

        @Override
        protected String doInBackground(String... params) {

            HttpCloudant http = new HttpCloudant();
            http.setRequest("https://9a90ba7e-9c8d-4150-8e5f-bccd9f2bead7-bluemix.cloudant.com/tec_db/_find");
            http.setRequestMethod("POST");
            http.setJson("{\"selector\": {\"tipo\": \"JOGADOR\"}}");

            try {
                HttpURLConnection client = http.getClient();
                int statusCodeHTTP = client.getResponseCode();
                StringBuilder sb = new StringBuilder();

                if (statusCodeHTTP == HttpURLConnection.HTTP_OK) {
                    BufferedReader br = new BufferedReader
                            (new InputStreamReader
                                    (client.getInputStream(), "utf-8"));
                    String line = null;

                    while ((line = br.readLine()) != null) {
                        sb.append(line + "\n");
                        Log.i("LINHA: ", line);
                    }

                    br.close();
                    client.disconnect();

                    return sb.toString();

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

    }

    private class criarPartidaTask extends AsyncTask<String,Void,String>{

        private ProgressDialog progress;

        @Override
        protected void onPreExecute(){
            progress = ProgressDialog.show
                    (SelecaoActivity.this, "Aguarde..", "Criando partida no servidor");
        }

        @Override
        protected void onPostExecute(String s){
            if(s.equals("sim")){
                Toast.makeText(SelecaoActivity.this, "Partida cadastrada com sucesso: " + s, Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(SelecaoActivity.this, s, Toast.LENGTH_LONG).show();
            }
        }

        @Override
        protected String doInBackground(String... params) {

            HttpCloudant http = new HttpCloudant();
            http.setRequest("https://9a90ba7e-9c8d-4150-8e5f-bccd9f2bead7-bluemix.cloudant.com/tec_db/");
            http.setRequestMethod("POST");

            HttpURLConnection client;

            String retorno = null;

            try{
                Partida part = new Partida();
                part.setCodigo(Integer.parseInt(params[0]));
                part.setCampeonato(params[1]);
                part.setNivel(params[2]);
                part.setTempo(Integer.parseInt(params[3]));
                part.setJogadorCasa(params[4]);
                part.setJogadorVisitante(params[5]);
                part.setHashtag();
                part.set_id();

                String log = "_id: " + part.get_id() + " - Código partida: " + part.getCodigo() + " - Campeonato: " + part.getCampeonato() +
                        " - Tempo: " + part.getTempo() + " - Gol: " + part.getGol() + " - Nível: " +
                        part.getNivel() + " - Jogador Casa: " + part.getJogadorCasa() + " - Jogador Visitante: " +
                        part.getJogadorVisitante() + " - Hashtag: " + part.getHashtag();
                Log.i("Dados: ", log);

                Gson gson = new Gson();

                String json = gson.toJson(part).toString();
                http.setJson(json);

                client = http.getClient();

                int statusCodeHTTP = client.getResponseCode();

                if(statusCodeHTTP == HttpURLConnection.HTTP_CREATED){
                    retorno = "sim" + part.getCodigo();
                }else{
                    retorno = statusCodeHTTP + client.getResponseMessage();
                }
            }catch(Exception e){
                e.printStackTrace();
            }
            return retorno;
        }
    }
}
