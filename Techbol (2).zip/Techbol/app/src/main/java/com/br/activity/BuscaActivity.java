package com.br.activity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.br.bean.Campeonato;
import com.br.bean.Partida;
import com.br.http.HttpCloudant;
import com.google.gson.Gson;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.List;

public class BuscaActivity extends AppCompatActivity {

    //Objetos
    private ListView liPartidas;
    private List<Partida> listaVerificacao;

    //Valores
    private String tituloCampeonato;
    private int qtdPartidas;
    private int qtdGols;
    private String _id;
    private String idPartida;

    //Verificação
    private boolean segue = true;

    //Alerta
    private AlertDialog alerta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_busca);

        liPartidas = (ListView) findViewById(R.id.livPartidas);

        Intent intent = getIntent();
        tituloCampeonato = intent.getStringExtra("tituloCampeonato");
        qtdPartidas = intent.getIntExtra("qtdPartidas", 1);
        qtdGols = intent.getIntExtra("qtdGols", 2);
        _id = intent.getStringExtra("id");

        new buscarTask().execute(tituloCampeonato);

        liPartidas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                view.setSelected(true);

                Partida partida = (Partida) adapterView.getItemAtPosition(i);
                idPartida = partida.get_id();


                switch(qtdPartidas){
                    case 3:
                        if(partida.getNivel().equals("FINAL")){
                            new verificarTask().execute(tituloCampeonato, "SEMI-FINAL");
                            segue = false;
                        }else{
                            segue = true;
                        }
                        break;
                    case 7:
                        //se a partida for diferente das quartas, elas mesmas deverão ser verificadas
                        if(partida.getNivel().equals("SEMI-FINAL")) {
                            new verificarTask().execute(tituloCampeonato, "QUARTAS-FINAL");
                            segue = false;
                        }else if (partida.getNivel().equals("FINAL")) {
                            new verificarTask().execute(tituloCampeonato, "SEMI-FINAL");
                            segue = false;
                        }else{
                            segue = true;
                        }

                        Log.i("VERIFICAÇÃO 2",String.valueOf(segue));
                        break;
                    default:
                        break;
                }

                if(segue){
                    Log.i("VERIFICAÇÃO 3",String.valueOf(segue));
                    Intent iniciar = new Intent(BuscaActivity.this, PartidaActivity.class);
                    iniciar.putExtra("id", partida.get_id());
                    iniciar.putExtra("qtdGols", qtdGols);
                    startActivity(iniciar);
                }

            }
        });
    }



    private void alertar(){

        //Cria o gerador do AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        //Define o título
        builder.setTitle("Alerta");
        //Define a mensagem
        builder.setMessage("Esta partida ainda não pode ser iniciada!");
        //Define um botão positivo
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                alerta.dismiss();
            }
        });

        //Cria o AlertDialog
        alerta = builder.create();
        //Exibe
        alerta.show();

    }

    private class buscarTask extends AsyncTask<String,Void,String>{

        private ProgressDialog progress;

        @Override
        protected void onPreExecute(){
            progress = ProgressDialog.show
                    (BuscaActivity.this, "Aguarde..", "Buscando dados no servidor");
        }

        @Override
        protected void onPostExecute(String s){

            progress.dismiss();
            if(s != null){
                JSONParser parser = new JSONParser();
                Log.i("JSON", s);
                JSONObject jsonSaida = null;
                try {
                    jsonSaida = (JSONObject) parser.parse(s);
                    JSONArray jsonArray = (JSONArray) jsonSaida.get("docs");

                    Gson gson = new Gson();

                    List<Partida> partidas = new ArrayList<>();

                    for (Object object : jsonArray) {
                        JSONObject jsonObj = (JSONObject) object;
                        Log.i("JSONObject:", jsonObj.toString());
                        partidas.add(gson.fromJson(jsonObj.toString(), Partida.class));
                        //retorno += jsonObj;
                    }

                    //Tipo de LIST CONVENCIONAL
                    ArrayAdapter<Partida> campeonatosArrayAdapter = new ArrayAdapter<Partida>
                            (BuscaActivity.this, android.R.layout.simple_list_item_1, partidas);

                    liPartidas.setAdapter(campeonatosArrayAdapter);

                } catch (ParseException e) {
                    e.printStackTrace();
                }

            }
        }

        @Override
        protected String doInBackground(String... params) {

            HttpCloudant http = new HttpCloudant();
            http.setRequest("https://9a90ba7e-9c8d-4150-8e5f-bccd9f2bead7-bluemix.cloudant.com/tec_db/_find");
            http.setRequestMethod("POST");
            http.setJson("{\"selector\": {\"campeonato\": \""+ params[0] +"\"}}");

            try {
                HttpURLConnection client = http.getClient();
                int statusCodeHTTP = client.getResponseCode();
                StringBuilder sb = new StringBuilder();

                if (statusCodeHTTP == HttpURLConnection.HTTP_OK) {
                    BufferedReader br = new BufferedReader
                            (new InputStreamReader
                                    (client.getInputStream(), "utf-8"));
                    String line = null;

                    while ((line = br.readLine()) != null) {
                        sb.append(line + "\n");
                        Log.i("LINHA: ", line);
                    }

                    br.close();
                    client.disconnect();

                    return sb.toString();

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    private class verificarTask extends AsyncTask<String,Void,String>{

        private ProgressDialog progress;

        @Override
        protected void onPreExecute(){
            progress = ProgressDialog.show
                    (BuscaActivity.this, "Aguarde..", "Buscando dados no servidor");
        }

        @Override
        protected void onPostExecute(String s){

            progress.dismiss();
            if(s != null){
                JSONParser parser = new JSONParser();
                Log.i("JSON", s);
                JSONObject jsonSaida = null;
                try {
                    jsonSaida = (JSONObject) parser.parse(s);
                    JSONArray jsonArray = (JSONArray) jsonSaida.get("docs");

                    Gson gson = new Gson();

                    listaVerificacao = new ArrayList<>();

                    for (Object object : jsonArray) {
                        JSONObject jsonObj = (JSONObject) object;
                        Log.i("JSONObject:", jsonObj.toString());
                        listaVerificacao.add(gson.fromJson(jsonObj.toString(), Partida.class));
                        //retorno += jsonObj;
                    }

                    boolean ok = true;

                    ok = executarVerificacao(listaVerificacao);

                    if(!ok){
                        alertar();
                    }else{
                        Log.i("VERIFICAÇÃO 3",String.valueOf(segue));
                        Intent iniciar = new Intent(BuscaActivity.this, PartidaActivity.class);
                        iniciar.putExtra("id", idPartida);
                        iniciar.putExtra("qtdGols", qtdGols);
                        startActivity(iniciar);
                    }

                } catch (ParseException e) {
                    e.printStackTrace();
                }

            }
        }

        private boolean executarVerificacao(List<Partida> list){
            boolean ok = true;
            for(Partida p: list){
                if((p.getVencedor().equals(""))){
                    ok = false;
                    Log.i("VERIFICAÇÃO",String.valueOf(ok));
                }
            }
            return ok;
        }

        @Override
        protected String doInBackground(String... params) {

            HttpCloudant http = new HttpCloudant();
            http.setRequest("https://9a90ba7e-9c8d-4150-8e5f-bccd9f2bead7-bluemix.cloudant.com/tec_db/_find");
            http.setRequestMethod("POST");
            http.setJson("{\"selector\": {\"campeonato\": \""+ params[0] +"\", \"nivel\": \"" + params[1] + "\"}}");

            try {
                HttpURLConnection client = http.getClient();
                int statusCodeHTTP = client.getResponseCode();
                StringBuilder sb = new StringBuilder();

                if (statusCodeHTTP == HttpURLConnection.HTTP_OK) {
                    BufferedReader br = new BufferedReader
                            (new InputStreamReader
                                    (client.getInputStream(), "utf-8"));
                    String line = null;

                    while ((line = br.readLine()) != null) {
                        sb.append(line + "\n");
                        Log.i("LINHA: ", line);
                    }

                    br.close();
                    client.disconnect();

                    return sb.toString();

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
