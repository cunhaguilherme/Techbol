package com.br.activity;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.br.bean.Campeonato;
import com.br.bean.Jogador;
import com.br.http.HttpCloudant;
import com.google.gson.Gson;

import java.net.HttpURLConnection;

public class CampeonatoActivity extends AppCompatActivity {

    private EditText edTituloCampeonato;
    private Spinner spQtdJogadores;
    private Spinner spTempoPartida;
    private Spinner spMaximoGols;
    private Button btCriar;

    private Campeonato camp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_campeonato);

        edTituloCampeonato = (EditText) findViewById(R.id.edtTituloCampeonato);
        spQtdJogadores = (Spinner) findViewById(R.id.spiQtdJogadores);
        spTempoPartida = (Spinner) findViewById(R.id.spiTempoPartida);
        spMaximoGols = (Spinner) findViewById(R.id.spiMaximoGols);
        btCriar = (Button) findViewById(R.id.btnCriar);
    }

    public void criar(View v){
        String titulo = edTituloCampeonato.getText().toString();
        String qtdJogadores = spQtdJogadores.getSelectedItem().toString();
        String tempoPartida = spTempoPartida.getSelectedItem().toString();
        String maximoGols = spMaximoGols.getSelectedItem().toString();

        if(titulo.length()>3){
            new CriarTask().execute(titulo, qtdJogadores, tempoPartida, maximoGols);
        }else{
            Toast.makeText(this, "Titulo inválido", Toast.LENGTH_SHORT).show();
        }
    }

    private class CriarTask extends AsyncTask<String,Void,String>{

        @Override
        protected String doInBackground(String... params) {

            HttpCloudant http = new HttpCloudant();
            http.setRequest("https://9a90ba7e-9c8d-4150-8e5f-bccd9f2bead7-bluemix.cloudant.com/tec_db/");
            http.setRequestMethod("POST");

            HttpURLConnection client;

            String retorno = null;

            try{
                camp = new Campeonato();
                camp.setTitulo(params[0]);
                camp.setQtdJogadores(Integer.parseInt(params[1]));
                camp.setTempo(Integer.parseInt(params[2]));
                camp.setMaximoGols(Integer.parseInt(params[3]));
                camp.setQtdPartidas();
                camp.set_id();

                String log = "_id: " + camp.get_id() + " - Titulo: " + camp.getTitulo() + " - Qtd Jogadores: " + camp.getQtdJogadores() +
                        " - Tempo: " + camp.getTempo() + " - Maximo Gols: " + camp.getMaximoGols() + " - Qtd Partidas: " +
                        camp.getQtdPartidas();
                Log.i("Dados: ", log);

                Gson gson = new Gson();

                String json = gson.toJson(camp).toString();
                http.setJson(json);

                client = http.getClient();

                int statusCodeHTTP = client.getResponseCode();

                if(statusCodeHTTP == HttpURLConnection.HTTP_CREATED){
                    retorno = "sim";
                }else{
                    retorno = statusCodeHTTP + client.getResponseMessage();
                }
            }catch(Exception e){
                e.printStackTrace();
            }
            return retorno;
        }

        @Override
        protected void onPostExecute(String s){
            if(s.equals("sim")){
                Toast.makeText(CampeonatoActivity.this, "Campeonato cadastrado com sucesso!", Toast.LENGTH_LONG).show();
                Intent selecao = new Intent(CampeonatoActivity.this, SelecaoActivity.class);
                selecao.putExtra("titulo",camp.getTitulo());
                selecao.putExtra("qtdJogadores", camp.getQtdJogadores());
                selecao.putExtra("tempo", camp.getTempo());
                startActivity(selecao);
            }else{
                Toast.makeText(CampeonatoActivity.this, s, Toast.LENGTH_SHORT).show();
            }
        }
    }
}
