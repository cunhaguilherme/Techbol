package com.br.activity;

import android.annotation.TargetApi;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.br.bean.Jogador;
import com.br.bean.Partida;
import com.br.http.HttpCloudant;
import com.br.util.Cronometro;
import com.google.gson.Gson;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.List;

public class PartidaActivity extends AppCompatActivity {

    //Objetos a serem mapeamos

    //Placar
    private TextView txtPlacarCasa;
    private TextView txtPlacarVisitante;
    private TextView txtCodigoPartida;
    private TextView txtTimer;
    private Cronometro cronometro;


    //Fotos Jogadores
    private ImageView imgCasa;
    private ImageView imgVisitante;

    //Nomes dos Jogadores
    private TextView txtCasa;
    private TextView txtVisitante;

    //Dados Jogadores
    private TextView txtCasaV;
    private TextView txtCasaE;
    private TextView txtCasaD;
    private TextView txtCasaG;

    private TextView txtVisitanteV;
    private TextView txtVisitanteE;
    private TextView txtVisitanteD;
    private TextView txtVisitanteG;

    //Botão Iniciar
    private Button btnIniciar;

    //Valores a serem recuperados da Intent
    private String partidaId;
    private int maximoGols;

    //Tempo da partida
    private static int tempoPartida;

    //Jogadores recuperados da primeira busca
    private static String jogadorCasa;
    private static String jogadorVisitante;

    //Valor de verificação de qual jogador está sendo buscado
    private static boolean jogador = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_partida);

        txtPlacarCasa = (TextView) findViewById(R.id.txtPlacarCasa);
        txtPlacarVisitante = (TextView) findViewById(R.id.txtPlacarVisitante);
        txtCodigoPartida = (TextView) findViewById(R.id.txtCodigo);
        txtTimer = (TextView) findViewById(R.id.txtTimer);



        imgCasa = (ImageView) findViewById(R.id.imgCasa);
        imgVisitante = (ImageView) findViewById(R.id.imgVisitante);

        txtCasa = (TextView) findViewById(R.id.txtCasa);
        txtVisitante = (TextView) findViewById(R.id.txtVisitante);

        txtCasaV = (TextView) findViewById(R.id.txtCasaVitorias);
        txtCasaE = (TextView) findViewById(R.id.txtCasaEmpates);
        txtCasaD = (TextView) findViewById(R.id.txtCasaDerrotas);
        txtCasaG = (TextView) findViewById(R.id.txtCasaGols);

        txtVisitanteV = (TextView) findViewById(R.id.txtVisitanteVitorias);
        txtVisitanteE = (TextView) findViewById(R.id.txtVisitanteEmpates);
        txtVisitanteD = (TextView) findViewById(R.id.txtVisitanteDerrotas);
        txtVisitanteG = (TextView) findViewById(R.id.txtVisitanteGols);

        btnIniciar = (Button) findViewById(R.id.btnIniciar);

        //Recuperar valores da Intent
        Intent intent = getIntent();
        partidaId = intent.getStringExtra("id");
        maximoGols = intent.getIntExtra("qtdGols",2);

        //Recuperando a partida e o nome dos jogadores
        new buscarPartidaTask().execute(partidaId);

    }

    public void iniciarPartida(View v){
        Toast.makeText(this, "Começaaa a partida!! A torcida vai à loucura!", Toast.LENGTH_LONG).show();
        cronometro = new Cronometro(this, txtTimer, (tempoPartida*60)*1000, 1000);
        cronometro.start();
    }

    public void carregarDados(){
        //Recuperando o jogador da casa
        try{
            Thread.sleep(2000);
        }catch (InterruptedException e){
            e.printStackTrace();
        }

        Log.i("VALIDAÇÃO3: ", jogadorCasa + " - " + jogadorVisitante);
        new buscarJogadorTask().execute(jogadorCasa);


        //Recuperando o jogador visitante
        new buscarJogadorTask().execute(jogadorVisitante);
    }

    private void carregarFoto(String localFoto, ImageView img) {

        FileInputStream imgFile;
        Bitmap imagemFoto = null;
        try{
            //Pegar o arquivo do armazenamento
            imgFile = new FileInputStream(localFoto);

            //Carregar arquivo de imagem
            imagemFoto = BitmapFactory.decodeStream(imgFile);

            //Fechar o InputStream
            imgFile.close();

        }catch(Exception e){
            e.printStackTrace();
        }

        if(imagemFoto != null){
            imagemFoto = Bitmap.createScaledBitmap(imagemFoto, 150, 150, true);
        }

        //Atualiza a imagem exibida na tela de cadastro
        img.setImageBitmap(imagemFoto);

    }

    private class buscarJogadorTask extends AsyncTask<String, Void, String>{

        private ProgressDialog progress;

        @Override
        protected void onPreExecute(){
            progress = ProgressDialog.show
                    (PartidaActivity.this, "Aguarde", "Carregando a partida!");
        }

        @Override
        protected void onPostExecute(String s){
                progress.dismiss();

            if(s != null) {
                JSONParser parser = new JSONParser();
                Log.i("JSON", s);
                JSONObject jsonSaida = null;
                try {
                    jsonSaida = (JSONObject) parser.parse(s);
                    JSONArray jsonArray = (JSONArray) jsonSaida.get("docs");

                    Gson gson = new Gson();

                    List<Jogador> jogadores = new ArrayList<>();

                    for (Object object : jsonArray) {
                        JSONObject jsonObj = (JSONObject) object;
                        Log.i("JSONObject:", jsonObj.toString());
                        jogadores.add(gson.fromJson(jsonObj.toString(), Jogador.class));
                        //retorno += jsonObj;
                    }


                    Jogador j = jogadores.get(0);
                    Log.i("VALIDAÇÃO: ", j.getNome() + " - " + j.getTwitter());

                    if(jogador){
                        txtVisitanteV.setText(""+j.getVitoria());
                        txtVisitanteE.setText(""+j.getEmpate());
                        txtVisitanteD.setText(""+j.getDerrota());
                        txtVisitanteG.setText(""+j.getGol());

                        carregarFoto(j.getFoto(),imgVisitante);
                    }else{
                        txtCasaV.setText(""+j.getVitoria());
                        txtCasaE.setText(""+j.getEmpate());
                        txtCasaD.setText(""+j.getDerrota());
                        txtCasaG.setText(""+j.getGol());

                        carregarFoto(j.getFoto(), imgCasa);
                    }

                    jogador = true;

                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }

        }

        @Override
        protected String doInBackground(String... params) {
            HttpCloudant http = new HttpCloudant();
            http.setRequest("https://9a90ba7e-9c8d-4150-8e5f-bccd9f2bead7-bluemix.cloudant.com/tec_db/_find");
            http.setRequestMethod("POST");
            http.setJson("{\"selector\": {\"nome\": \""+ params[0] + "\"}}");

            try {
                HttpURLConnection client = http.getClient();
                int statusCodeHTTP = client.getResponseCode();
                StringBuilder sb = new StringBuilder();

                if (statusCodeHTTP == HttpURLConnection.HTTP_OK) {
                    BufferedReader br = new BufferedReader
                            (new InputStreamReader
                                    (client.getInputStream(), "utf-8"));
                    String line = null;

                    while ((line = br.readLine()) != null) {
                        sb.append(line + "\n");
                        Log.i("LINHA: ", line);
                    }

                    br.close();
                    client.disconnect();

                    return sb.toString();

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    private class buscarPartidaTask extends AsyncTask<String, Void, String>{

        @Override
        protected void onPostExecute(String s){

            if(s != null) {
                JSONParser parser = new JSONParser();
                Log.i("JSON", s);
                JSONObject jsonSaida = null;
                try {
                    jsonSaida = (JSONObject) parser.parse(s);
                    JSONArray jsonArray = (JSONArray) jsonSaida.get("docs");

                    Gson gson = new Gson();

                    List<Partida> partida = new ArrayList<>();

                    for (Object object : jsonArray) {
                        JSONObject jsonObj = (JSONObject) object;
                        Log.i("JSONObject:", jsonObj.toString());
                        partida.add(gson.fromJson(jsonObj.toString(), Partida.class));
                        //retorno += jsonObj;
                    }

                    //Recuperando os nomes dos jogadores para posterior busca
                    Partida p = partida.get(0);
                    Log.i("VALIDAÇÃO: ",p.getNivel());
                    jogadorCasa = p.getJogadorCasa();
                    jogadorVisitante = p.getJogadorVisitante();
                    Log.i("VALIDAÇÃO2: ", jogadorCasa + " - " + jogadorVisitante);

                    //Setando o tempo da partida
                    tempoPartida = p.getTempo();

                    //Setando o código da partida
                    Log.i("VALIDAÇÃO: ",""+p.getCodigo());
                    txtCodigoPartida.setText("" + p.getCodigo());

                    //Setando os nomes dos jogadores
                    txtCasa.setText(p.getJogadorCasa());
                    txtVisitante.setText(p.getJogadorVisitante());

                    carregarDados();

                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        }

        @Override
        protected String doInBackground(String... params) {

            HttpCloudant http = new HttpCloudant();
            http.setRequest("https://9a90ba7e-9c8d-4150-8e5f-bccd9f2bead7-bluemix.cloudant.com/tec_db/_find");
            http.setRequestMethod("POST");
            http.setJson("{\"selector\": {\"_id\": \""+ params[0] + "\"}}");

            try {
                HttpURLConnection client = http.getClient();
                int statusCodeHTTP = client.getResponseCode();
                StringBuilder sb = new StringBuilder();

                if (statusCodeHTTP == HttpURLConnection.HTTP_OK) {
                    BufferedReader br = new BufferedReader
                            (new InputStreamReader
                                    (client.getInputStream(), "utf-8"));
                    String line = null;

                    while ((line = br.readLine()) != null) {
                        sb.append(line + "\n");
                        Log.i("LINHA: ", line);
                    }

                    br.close();
                    client.disconnect();

                    return sb.toString();

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
