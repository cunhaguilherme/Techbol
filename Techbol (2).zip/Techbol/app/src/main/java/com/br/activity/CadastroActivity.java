package com.br.activity;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.br.bean.Jogador;
import com.br.http.HttpCloudant;
import com.google.gson.Gson;

import java.io.File;
import java.io.FileInputStream;
import java.net.HttpURLConnection;
import java.util.ArrayList;

public class CadastroActivity extends AppCompatActivity {

    private ImageView imJogador;
    private EditText edNome;
    private EditText edTwitter;
    private Spinner spSerie;
    private Button btCadastrar;
    private AlertDialog alerta;

    //Atributos para foto
    static String imgString = Environment.getExternalStorageDirectory() + "/" + System.currentTimeMillis() + ".jpg";
    private File imageFile;
    private static Uri tempuri;
    private static final int IMAGE_GALLERY_REQUEST = 1;
    private static String caminhoFoto = null;

    // Storage Permissions
    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        imJogador = (ImageView) findViewById(R.id.imgJogador);
        edNome = (EditText) findViewById(R.id.edtNome);
        edTwitter = (EditText) findViewById(R.id.edtTwitter);
        spSerie = (Spinner) findViewById(R.id.spiSerie);
        btCadastrar = (Button) findViewById(R.id.btnCadastrar);

        imJogador.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                escolherOpcaoFoto(v);
            }
        });
    }

    private void escolherOpcaoFoto(final View v) {
        //Lista de itens
        ArrayList<String> itens = new ArrayList<String>();
        itens.add("Tirar uma foto");
        itens.add("Escolher da galeria");

        //Adapter utilizando um layout customizado (TextView)
        ArrayAdapter adapter = new ArrayAdapter(this, R.layout.alert_item, itens);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        //Customizar o titulo do alerta
        LayoutInflater inflater = LayoutInflater.from(getApplicationContext());
        View customTitle = inflater.inflate(R.layout.titulo_alerta, null);
        builder.setCustomTitle(customTitle);

        //Define o diálogo como uma lista, passando o adapter
        builder.setSingleChoiceItems(adapter, 0, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    tirarFoto();
                } else {
                    selecionarFoto(v);
                }

                alerta.dismiss();
            }

        });

        alerta = builder.create();
        alerta.show();
    }

    private void tirarFoto() {
        verifyStoragePermissions(this);
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        String arquivo = imgString;
        imageFile = new File(arquivo);
        tempuri = Uri.fromFile(imageFile);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, tempuri);
        intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1);
        startActivityForResult(intent, 0);
    }

    private void selecionarFoto(View v){
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED) {

            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, 2);

        }else{

            ActivityCompat.requestPermissions(this,
                    new String[]{ Manifest.permission.READ_EXTERNAL_STORAGE },
                    IMAGE_GALLERY_REQUEST);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        //Se a opção escolhida foi tirar a foto
        if(requestCode == 0){
            switch(resultCode){
                case Activity.RESULT_OK:
                    carregarFoto(imgString);
                    break;
                case Activity.RESULT_CANCELED:
                    Toast.makeText(this, "Falha ao salvar a imagem", Toast.LENGTH_SHORT).show();
                    break;
                default:
                    break;
            }

        }else{
        //Se a opção escolhida foi selecionar uma foto
            switch (resultCode){
                case Activity.RESULT_OK:
                    tempuri = data.getData();
                    String[] filePath = {MediaStore.Images.Media.DATA};

                    Cursor c = getContentResolver().query(tempuri,filePath,null,null,null);
                    c.moveToFirst();

                    int columnIndex = c.getColumnIndex(filePath[0]);

                    String picturePath = c.getString(columnIndex);

                    c.close();

                    carregarFoto(picturePath);
                    break;
                case Activity.RESULT_CANCELED:
                    Toast.makeText(this, "Aconteceu uma falha ao selecionar uma imagem da galeria",Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    }

    private void carregarFoto(String localFoto) {

        FileInputStream imgFile;
        Bitmap imagemFoto = null;
        try{
            //Pegar o arquivo do armazenamento
            imgFile = new FileInputStream(localFoto);

            //Carregar arquivo de imagem
            imagemFoto = BitmapFactory.decodeStream(imgFile);

            //Fechar o InputStream
            imgFile.close();

        }catch(Exception e){
            e.printStackTrace();
        }

        if(imagemFoto != null){
            imagemFoto = Bitmap.createScaledBitmap(imagemFoto, 200, 220, true);
        }

        //Guarda o caminho da foto do usuário
        caminhoFoto = localFoto;

        //Atualiza a imagem exibida na tela de cadastro
        imJogador.setImageBitmap(imagemFoto);

    }

    public void cadastrar(View v){
        String nome = edNome.getText().toString();
        String twitter = edTwitter.getText().toString();
        String serie = spSerie.getSelectedItem().toString();

        if(nome.length()>=4 && twitter.length()>3){
            new CadastrarTask().execute(nome,twitter,serie, caminhoFoto);
        }else{
            Toast.makeText(this, "Dados inválidos para cadastro!",Toast.LENGTH_SHORT).show();
        }
    }

    public static void verifyStoragePermissions(Activity activity) {
        // Check if we have write permission
        int permission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);

        if (permission != PackageManager.PERMISSION_GRANTED) {
            // We don't have permission so prompt the user
            ActivityCompat.requestPermissions(
                    activity,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
            );
        }
    }

    private class CadastrarTask extends AsyncTask<String,Void,String>{

        private ProgressDialog progress;

        @Override
        protected void onPreExecute(){
            progress = ProgressDialog.show
                    (CadastroActivity.this, "Aguarde..", "Enviando dados para o servidor");
        }

        @Override
        protected String doInBackground(String... params) {

            HttpCloudant http = new HttpCloudant();
            http.setRequest("https://9a90ba7e-9c8d-4150-8e5f-bccd9f2bead7-bluemix.cloudant.com/tec_db/");
            http.setRequestMethod("POST");

            HttpURLConnection client;

            String retorno = null;

            try{
                Jogador jog = new Jogador();
                jog.setNome(params[0]);
                jog.setTwitter(params[1]);
                jog.setSerie(params[2]);
                jog.setFoto(params[3]);
                jog.setVitoria(0);
                jog.setEmpate(0);
                jog.setDerrota(0);
                jog.setGol(0);

                String log = "Nome: " + jog.getNome() + " - Twitter: " + jog.getTwitter() +
                             " - Série: " + jog.getSerie() + " - Foto: " + jog.getFoto();
                Log.i("Dados: ", log);

                Gson gson = new Gson();

                String json = gson.toJson(jog).toString();
                http.setJson(json);

                client = http.getClient();

                int statusCodeHTTP = client.getResponseCode();

                if(statusCodeHTTP == HttpURLConnection.HTTP_CREATED){
                    retorno = "sim";
                }else{
                    retorno = statusCodeHTTP + client.getResponseMessage();
                }
            }catch(Exception e){
                e.printStackTrace();
            }
            return retorno;
        }

        @Override
        protected void onPostExecute(String s){
            if(s.equals("sim")){
                Toast.makeText(CadastroActivity.this, "Jogador cadastrado com sucesso!", Toast.LENGTH_LONG).show();
                Intent navegacao = new Intent(CadastroActivity.this, NavegacaoActivity.class);
                startActivity(navegacao);
            }else{
                Toast.makeText(CadastroActivity.this, s, Toast.LENGTH_SHORT).show();
            }
        }
    }
}
