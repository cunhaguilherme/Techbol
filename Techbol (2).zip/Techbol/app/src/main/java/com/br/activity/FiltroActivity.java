package com.br.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.br.bean.Campeonato;
import com.br.bean.Jogador;
import com.br.http.HttpCloudant;
import com.br.list.ListaJogadoresAdapter;
import com.google.gson.Gson;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.List;

public class FiltroActivity extends AppCompatActivity {

    private ListView liCampeonatos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filtro);

        liCampeonatos = (ListView) findViewById(R.id.livCampeonatos);

        new SelecionarTask().execute();

        liCampeonatos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Campeonato c = (Campeonato) adapterView.getItemAtPosition(i);
                Toast.makeText(FiltroActivity.this, "Campeonato: " + c.getTitulo(), Toast.LENGTH_SHORT).show();
                Intent filtroPartida = new Intent(FiltroActivity.this, BuscaActivity.class);
                filtroPartida.putExtra("tituloCampeonato",c.getTitulo());
                filtroPartida.putExtra("id",c.get_id());
                filtroPartida.putExtra("qtdPartidas",c.getQtdPartidas());
                filtroPartida.putExtra("qtdGols", c.getMaximoGols());
                startActivity(filtroPartida);
            }
        });
    }

    private class SelecionarTask extends AsyncTask<String,Void,String> {

        private ProgressDialog progress;

        @Override
        protected void onPreExecute(){
            progress = ProgressDialog.show
                    (FiltroActivity.this, "Aguarde..", "Buscando dados no servidor");
        }

        @Override
        protected void onPostExecute(String s){
            progress.dismiss();
            if(s != null){
                JSONParser parser = new JSONParser();
                Log.i("JSON", s);
                JSONObject jsonSaida = null;
                try {
                    jsonSaida = (JSONObject) parser.parse(s);
                    JSONArray jsonArray = (JSONArray) jsonSaida.get("docs");

                    Gson gson = new Gson();

                    List<Campeonato> campeonatos = new ArrayList<>();

                    for (Object object : jsonArray) {
                        JSONObject jsonObj = (JSONObject) object;
                        Log.i("JSONObject:", jsonObj.toString());
                        campeonatos.add(gson.fromJson(jsonObj.toString(), Campeonato.class));
                        //retorno += jsonObj;
                    }

                    //Tipo de LIST CONVENCIONAL
                    ArrayAdapter<Campeonato> campeonatosArrayAdapter = new ArrayAdapter<Campeonato>
                    (FiltroActivity.this, android.R.layout.simple_list_item_1, campeonatos);

                    liCampeonatos.setAdapter(campeonatosArrayAdapter);

                } catch (ParseException e) {
                    e.printStackTrace();
                }

            }
        }

        @Override
        protected String doInBackground(String... params) {

            HttpCloudant http = new HttpCloudant();
            http.setRequest("https://9a90ba7e-9c8d-4150-8e5f-bccd9f2bead7-bluemix.cloudant.com/tec_db/_find");
            http.setRequestMethod("POST");
            http.setJson("{\"selector\": {\"tipo\": \"CAMPEONATO\"}}");

            try {
                HttpURLConnection client = http.getClient();
                int statusCodeHTTP = client.getResponseCode();
                StringBuilder sb = new StringBuilder();

                if (statusCodeHTTP == HttpURLConnection.HTTP_OK) {
                    BufferedReader br = new BufferedReader
                            (new InputStreamReader
                                    (client.getInputStream(), "utf-8"));
                    String line = null;

                    while ((line = br.readLine()) != null) {
                        sb.append(line + "\n");
                        Log.i("LINHA: ", line);
                    }

                    br.close();
                    client.disconnect();

                    return sb.toString();

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

    }
}
